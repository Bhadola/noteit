package com.example.noteit;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.NoteViewHolder> implements Filterable {

    ArrayList<NoteData> noteData = new ArrayList<NoteData>();
    static Context context;
    List <NoteData> noteDatafull;

    public NotesAdapter(ArrayList<NoteData> noteData,Context context) {
        this.noteData = noteData;
        this.context=context;
        noteDatafull=new ArrayList<>(noteData);
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NoteViewHolder(LayoutInflater.from(parent.getContext()).inflate(
                R.layout.contextview,
                parent,
                false
        )
        );
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {

        NoteData currentitem=noteData.get(position);
        holder.textTitle.setText(currentitem.getTitle());
        holder.textDateTime.setText(currentitem.getDatetime());
        holder.linearLayout.setBackgroundResource(currentitem.getColor());

        holder.linearLayout.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                builder.setMessage("Are you Sure you want to Delete this Note \n:- "+currentitem.getTitle());
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((MainActivity)context).deleteNote(position);
                        Toast.makeText(context,"Note Deleted",Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.setCancelable(false);
                builder.show();
            return false;}
        });

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(context instanceof MainActivity)
                    ((MainActivity)context).editIntent(currentitem,position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return noteData.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }


    static class NoteViewHolder extends RecyclerView.ViewHolder{
        TextView textTitle,textDateTime;
        LinearLayout linearLayout;

        NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle=itemView.findViewById(R.id.textTitleid);
            textDateTime=itemView.findViewById(R.id.textDateTimeid);
            linearLayout=itemView.findViewById(R.id.layoutNote);



        }
    }
    @Override
    public Filter getFilter() {
        return NoteDataFilter;
    }
    private Filter NoteDataFilter=new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<NoteData> filteredList=new ArrayList<>();
            if(constraint==null||constraint.length()==0)
                filteredList.addAll(noteDatafull);
            else
            {
                String filterpattern=constraint.toString().toLowerCase().trim();
                for (NoteData item:noteDatafull)
                    if(item.getTitle().toLowerCase().contains(filterpattern))
                        filteredList.add(item);
            }
            FilterResults filterResults=new FilterResults();
            filterResults.values=filteredList;
            return filterResults;

        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            noteData.clear();
            noteData.addAll((Collection<? extends NoteData>) results.values);
            notifyDataSetChanged();

        }
    };

}
