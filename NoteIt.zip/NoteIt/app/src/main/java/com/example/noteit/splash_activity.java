package com.example.noteit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import android.app.KeyguardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.Executor;

public class splash_activity extends AppCompatActivity {
    Button auth;
    static private KeyguardManager keyguardManager;
    Animation topanim, bottomanim, right;
    private BiometricPrompt biometricPrompt;
    private BiometricPrompt.PromptInfo promptInfo;
    Executor executor;
    ImageView big, note1, note2, pen, ball1, ball2;
    TextView title, text;
    boolean checkfp = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_activity);
        //setHooks
        setAllhooks();
        setAnimation();
        checkfp = checkBiometricSupport();
        if (checkfp == true) {
            executor = ContextCompat.getMainExecutor(this);
            biometricPrompt = new BiometricPrompt(splash_activity.this, executor, new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                    Toast.makeText(getApplicationContext(),
                            "Authentication failed! Long press to access guest Notes", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    Intent i = new Intent(splash_activity.this, MainActivity.class);
                    i.putExtra("shared_pref_user", "User");
                    startActivity(i);

                }

                @Override
                public void onAuthenticationFailed() {
                    super.onAuthenticationFailed();
                    Toast.makeText(getApplicationContext(), "Authentication failed",
                            Toast.LENGTH_SHORT)
                            .show();
                }
            });
            promptInfo = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Biometric login for NoteIt")
                    .setSubtitle("Log in using your biometric credential")
                    .setNegativeButtonText("Use guest account")
                    .build();
        }
        auth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkfp == true)
                    biometricPrompt.authenticate(promptInfo);
                else
                    Toast.makeText(getApplicationContext(),
                            "Long press to access guest Notes", Toast.LENGTH_SHORT).show();
            }
        });//checkedfor biometric
        auth.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent i = new Intent(splash_activity.this, MainActivity.class);
                i.putExtra("shared_pref_user", "guest");
                startActivity(i);

                return false;
            }
        });


    }

    private void setAnimation() {
        big.setAnimation(topanim);
        note1.setAnimation(topanim);
        note2.setAnimation(topanim);
        pen.setAnimation(topanim);
        title.setAnimation(bottomanim);
        text.setAnimation(bottomanim);
        auth.setAnimation(bottomanim);
    }


    private Boolean checkBiometricSupport() {

        PackageManager packageManager = this.getPackageManager();
        keyguardManager= (KeyguardManager) getSystemService(KEYGUARD_SERVICE);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            Toast.makeText(splash_activity.this, "This Android version does not support fingerprint authentication.", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)) {
            Toast.makeText(splash_activity.this, "Fingerprint Sensor not supported ", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!keyguardManager.isKeyguardSecure()) {
            Toast.makeText(splash_activity.this, "Lock screen security not enabled in Settings", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void setAllhooks() {

        auth = findViewById(R.id.biometric_login);

        topanim = AnimationUtils.loadAnimation(this, R.anim.top_anim);
        bottomanim = AnimationUtils.loadAnimation(this, R.anim.bottom_anim);
        right = AnimationUtils.loadAnimation(this, R.anim.right);

        big = findViewById(R.id.imageView3);
        note1 = findViewById(R.id.imageView4);
        note2 = findViewById(R.id.imageView5);
        pen = findViewById(R.id.imageView6);
        ball1 = findViewById(R.id.imageView);
        ball2 = findViewById(R.id.imageView2);
        title = findViewById(R.id.textView);
        text = findViewById(R.id.textView2);
    }
}