package com.example.noteit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetBehavior;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class addnoteactivity extends AppCompatActivity {
    ImageView done, back;
    View notecolor, bottomsheetview;
    EditText title, data;
    TextView datetime;
    ImageView c1, c2, c3, c4, c5, expandsheetbutton;
    private BottomSheetBehavior bottomSheetBehavior;
    private int checksheet = 0;
    String Titlestr, Datastr, datetimestr;
    int color = R.drawable.notecolor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addnoteactivity);
        //hooks
        done = findViewById(R.id.imageSave);
        back = findViewById(R.id.imageBack);
        notecolor = findViewById(R.id.viewSubtitleIndicator);
        expandsheetbutton = findViewById(R.id.expanderimage);
        texthooks();  //dateTimehere
        colorhooks();
        bottomsheethooks();


        expandsheetbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checksheet == 0) {
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                    expandsheetbutton.setImageDrawable(getDrawable(R.drawable.ic_down));
                    checksheet = 1;
                } else {
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                    expandsheetbutton.setImageDrawable(getDrawable(R.drawable.ic_up));
                    checksheet = 0;
                }
            }
        }); //expand sheet listener
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });     //backlistener
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Titlestr = title.getText().toString();
                Datastr = data.getText().toString();
                datetimestr = datetime.getText().toString().trim();
                if (!Titlestr.isEmpty()) {
                    NoteData noteData = new NoteData(Titlestr, Datastr, datetimestr, color);
                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    i.putExtra("intentdata", noteData);
                    setResult(RESULT_OK, i);
                    finish();
                } else if (Titlestr.isEmpty())
                    Toast.makeText(getApplicationContext(), "Title must not be empty", Toast.LENGTH_SHORT).show();
            }
        });        //donelistener
    }

    private void texthooks() {
        title = findViewById(R.id.inputnotetitle);
        datetime = findViewById(R.id.textDateTime);
        data = findViewById(R.id.inputNote);
        datetime.setText(
                new SimpleDateFormat("EE dd/MM/yy HH:mm", Locale.getDefault())
                        .format(new Date())
        );
    }

    private void bottomsheethooks() {
        bottomsheetview = findViewById(R.id.bottomsheet);
        bottomSheetBehavior = BottomSheetBehavior.from(bottomsheetview);
        bottomSheetBehavior.setHideable(true);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        bottomSheetBehavior.setPeekHeight(100);

    }

    private void colorhooks() {
        c1 = findViewById(R.id.imagecolor1);
        c2 = findViewById(R.id.imagecolor2);
        c3 = findViewById(R.id.imagecolor3);
        c4 = findViewById(R.id.imagecolor4);
        c5 = findViewById(R.id.imagecolor5);
    }

    private void setinvisible() {
        c1.setVisibility(View.INVISIBLE);
        c2.setVisibility(View.INVISIBLE);
        c3.setVisibility(View.INVISIBLE);
        c4.setVisibility(View.INVISIBLE);
        c5.setVisibility(View.INVISIBLE);

    }

    public void setcolor1(View view) {
        setinvisible();
        c1.setVisibility(View.VISIBLE);
        notecolor.setBackground(getDrawable(R.drawable.notecolor1));
        color = R.drawable.notecolor1;
    }

    public void setcolor2(View view) {
        setinvisible();
        c2.setVisibility(View.VISIBLE);
        notecolor.setBackground(getDrawable(R.drawable.notecolor2));
        color = R.drawable.notecolor2;
    }

    public void setcolor3(View view) {
        setinvisible();
        c3.setVisibility(View.VISIBLE);
        notecolor.setBackground(getDrawable(R.drawable.notecolor3));
        color = R.drawable.notecolor3;
    }

    public void setcolor4(View view) {
        setinvisible();
        c4.setVisibility(View.VISIBLE);
        notecolor.setBackground(getDrawable(R.drawable.notecolor4));
        color = R.drawable.notecolor4;
    }

    public void setcolor5(View view) {
        setinvisible();
        c5.setVisibility(View.VISIBLE);
        notecolor.setBackground(getDrawable(R.drawable.notecolor5));
        color = R.drawable.notecolor5;
    }


}