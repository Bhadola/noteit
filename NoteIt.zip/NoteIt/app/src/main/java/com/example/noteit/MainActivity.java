package com.example.noteit;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.widget.SearchView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    FloatingActionButton fab;
    RecyclerView recyclerView;
    ArrayList<NoteData> noteData = new ArrayList<NoteData>();
    SharedPreferences sharedPreferences;
    NotesAdapter notesAdapter;
    SearchView searchView;
    String prefuser;


    private final static int MY_REQUEST_CODE = 1, MY_REQUEST_CODE2 = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //hooks
        fab = findViewById(R.id.addnoteimage);
        searchView=findViewById(R.id.searchview);
        prefuser=getIntent().getStringExtra("shared_pref_user").trim();
        Toast.makeText(MainActivity.this,"Welcome "+prefuser,Toast.LENGTH_SHORT).show();

        loadData();
        setRecyclerview();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), addnoteactivity.class);
                startActivityForResult(i, MY_REQUEST_CODE);
            }
        });    //fab

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {


                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                notesAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }

    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences(""+prefuser, MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("task list", null);
        Type type = new TypeToken<ArrayList<NoteData>>() {
        }.getType();
        noteData = gson.fromJson(json, type);
        if (noteData == null) {
            noteData = new ArrayList<>();
        }
    }

    private void setRecyclerview() {
        notesAdapter = new NotesAdapter(noteData, MainActivity.this);
        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(
                new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        );
        recyclerView.setAdapter(notesAdapter);
    }

    private void saveData() {
        sharedPreferences = getSharedPreferences(""+prefuser, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(noteData);
        editor.putString("task list", json);
        editor.apply();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == MY_REQUEST_CODE) {
                NoteData obj = data.getParcelableExtra("intentdata");
                if (obj != null) {
                    Toast.makeText(getApplicationContext(), "Note added", Toast.LENGTH_SHORT).show();

                    noteData.add(noteData.size(),obj);
                    notesAdapter.notifyItemInserted(noteData.size());
                    recyclerView.smoothScrollToPosition(0);
                    saveData();         //saves to sharedpreferences
                    setRecyclerview();
                }
            } else if (requestCode == MY_REQUEST_CODE2) {
                NoteData obj = data.getParcelableExtra("Edit_done");
                int pos=data.getIntExtra("Edit_done_position",0);
                if (obj != null) {
                    noteData.remove(pos);
                    noteData.add(noteData.size(),obj);
                    saveData();
                    setRecyclerview();
                }
            }


        }
    }

    public void editIntent(NoteData currentitem, int position) {            //edit calls from adapter class
        Intent i = new Intent(getApplicationContext(), editactivity.class);
        i.putExtra("Edit_note", currentitem);
        i.putExtra("Edit_note_position", position);
        startActivityForResult(i, MY_REQUEST_CODE2);
    }

    public void deleteNote(int pos) {
        noteData.remove(pos);
        notesAdapter.notifyItemRemoved(pos);
        saveData();
    }
}