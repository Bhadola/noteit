package com.example.noteit;

import android.os.Parcel;
import android.os.Parcelable;

public class NoteData implements Parcelable {
    private String title, data, datetime;
    int color;

    public NoteData(String title, String data, String datetime, int color) {
        this.title = title;
        this.data = data;
        this.datetime = datetime;
        this.color = color;
    }

    protected NoteData(Parcel in) {
        title = in.readString();
        data = in.readString();
        datetime = in.readString();
        color = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(data);
        dest.writeString(datetime);
        dest.writeInt(color);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<NoteData> CREATOR = new Creator<NoteData>() {
        @Override
        public NoteData createFromParcel(Parcel in) {
            return new NoteData(in);
        }

        @Override
        public NoteData[] newArray(int size) {
            return new NoteData[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public String getData() {
        return data;
    }

    public String getDatetime() {
        return datetime;
    }

    public int getColor() {
        return color;
    }

}
